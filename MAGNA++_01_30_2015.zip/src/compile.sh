make -f Makefile all
make -f Makefile gui
mv magna ../execs/magnapp_cli_linux64
mv magnafluidui ../execs/magnapp_gui_linux64
#mv magna.exe ../execs/magnapp_cli_win32.exe
#mv magnafluidui.exe ../execs/magnapp_gui_win32.exe
