###################
##### AUTHORS #####
###################

Written by Vikram Saraph (vikram_saraph@brown.edu, vsaraph@nd.edu)
And Vipin Vijayan (vvijayan@nd.edu)
In collaboration with Prof. Tijana Milenkovic (tmilenko@nd.edu)

#######################
##### DESCRIPTION #####
#######################

Please read the documentation and tutorial provided in http://www3.nd.edu/~cone/MAGNA++/ for usage instructions for the graphical user interface.
